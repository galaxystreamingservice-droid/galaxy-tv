package com.galaxymedia.tvsetup

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("galaxy", Context.MODE_PRIVATE)

    var settingsUrl: String
        get() = sp.getString("settingsUrl", "") ?: ""
        set(v) = sp.edit().putString("settingsUrl", v).apply()

    var lastSettingsJson: String
        get() = sp.getString("lastSettings", "") ?: ""
        set(v) = sp.edit().putString("lastSettings", v).apply()

    var lastSync: Long
        get() = sp.getLong("lastSync", 0L)
        set(v) = sp.edit().putLong("lastSync", v).apply()

    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    var namePrompted: Boolean
        get() = sp.getBoolean("namePrompted", false)
        set(v) = sp.edit().putBoolean("namePrompted", v).apply()

    var accent: String
        get() = sp.getString("accent", "cyan") ?: "cyan"
        set(v) = sp.edit().putString("accent", v).apply()

    var wallpaper: String
        get() = sp.getString("wallpaper", "season") ?: "season"
        set(v) = sp.edit().putString("wallpaper", v).apply()

    /** Minutes between changes when the background is "rotate". */
    var rotateMin: Int
        get() = sp.getInt("rotateMin", 10)
        set(v) = sp.edit().putInt("rotateMin", v).apply()

    /** "auto" (the stick's model decides), "on" (full animation) or "off" (backgrounds stand still). */
    var animations: String
        get() = sp.getString("animations", "auto") ?: "auto"
        set(v) = sp.edit().putString("animations", v).apply()

    /** How smoothly a moving background draws on this stick: "smooth", "ok" or "heavy" (measured). */
    fun setBgSpeed(key: String, rating: String, p90ms: Int) {
        sp.edit().putString("spd_$key", "$rating|$p90ms|${System.currentTimeMillis()}").apply()
    }

    fun bgSpeed(key: String): Triple<String, Int, Long>? {
        val v = sp.getString("spd_$key", null) ?: return null
        val p = v.split("|")
        if (p.size < 3) return null
        return Triple(p[0], p[1].toIntOrNull() ?: 0, p[2].toLongOrNull() ?: 0L)
    }

    /** Backgrounds measured as heavy within the last 7 days. Rotate skips these. */
    fun heavyBackgrounds(): Set<String> {
        val now = System.currentTimeMillis()
        return sp.all.keys.filter { it.startsWith("spd_") }.mapNotNull { k ->
            val key = k.removePrefix("spd_")
            val t = bgSpeed(key)
            if (t != null && t.first == "heavy" && now - t.third < 7L * 24 * 3600 * 1000) key else null
        }.toSet()
    }

    /** "Restart for best speed" is hidden until this time after pressing Not now. */
    var restartSnoozeUntil: Long
        get() = sp.getLong("restartSnoozeUntil", 0L)
        set(v) = sp.edit().putLong("restartSnoozeUntil", v).apply()

    /** Close other apps when coming back to Galaxy Media: "auto", "on" or "off". */
    var closeApps: String
        get() = sp.getString("closeApps", "auto") ?: "auto"
        set(v) = sp.edit().putString("closeApps", v).apply()

    /** The renewal reminder the person set on this stick, "yyyy-MM-dd", or blank. */
    var reminderDate: String
        get() = sp.getString("reminderDate", "") ?: ""
        set(v) = sp.edit().putString("reminderDate", v).apply()

    /** The last payment screen details, so it still opens offline. */
    var paymentCache: String
        get() = sp.getString("paymentCache", "") ?: ""
        set(v) = sp.edit().putString("paymentCache", v).apply()

    /** The last connection test, for the Stick health screen. */
    var lastSpeed: String
        get() = sp.getString("lastSpeed", "") ?: ""
        set(v) = sp.edit().putString("lastSpeed", v).apply()
    var lastSpeedMbps: Float
        get() = sp.getFloat("lastSpeedMbps", -1f)
        set(v) = sp.edit().putFloat("lastSpeedMbps", v).apply()
    var lastSpeedAt: Long
        get() = sp.getLong("lastSpeedAt", 0L)
        set(v) = sp.edit().putLong("lastSpeedAt", v).apply()

    private var bootTimes: String
        get() = sp.getString("bootTimes", "") ?: ""
        set(v) = sp.edit().putString("bootTimes", v).apply()

    /** Called when the app starts. If the stick has restarted since last time, remember when. */
    fun noteBoot(nowMs: Long, upMs: Long) {
        val bootAt = nowMs - upMs
        val last = sp.getLong("lastBootAt", 0L)
        if (last != 0L && kotlin.math.abs(bootAt - last) > 120_000L) {
            val keep = bootTimes.split(",").mapNotNull { it.toLongOrNull() }.filter { nowMs - it < 14L * 24 * 3600 * 1000 }
            bootTimes = (keep + bootAt).joinToString(",")
        }
        if (last == 0L || kotlin.math.abs(bootAt - last) > 120_000L) sp.edit().putLong("lastBootAt", bootAt).apply()
    }

    fun restartsSince(sinceMs: Long): Int = bootTimes.split(",").mapNotNull { it.toLongOrNull() }.count { it >= sinceMs }

    /** Color of the running light on the picture and frame wallpapers. */
    var beam: String
        get() = sp.getString("beam", "gold") ?: "gold"
        set(v) = sp.edit().putString("beam", v).apply()

    /** "normal" or "wide": how far the home screen stays from the TV edge (some TVs crop the edge). */
    var edge: String
        get() = sp.getString("edge", "normal") ?: "normal"
        set(v) = sp.edit().putString("edge", v).apply()

    /** "off", "my" (my teams only) or "all" (all games today). */
    var sports: String
        get() = sp.getString("sports", "all") ?: "all"
        set(v) = sp.edit().putString("sports", v).apply()

    /** "bottom" (row along the bottom) or "left" (rail down the left side). */
    var shelf: String
        get() = "bottom"   // the apps always sit along the bottom (the left-side rail was retired)
        set(v) = sp.edit().putString("shelf", v).apply()

    /** Favorite teams, one entry each like "NFL:DAL|Cowboys" (league:abbreviation|name). */
    var myTeams: Set<String>
        get() = sp.getStringSet("myTeams", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("myTeams", v.toSet()).apply()

    /** Package names of shelf apps this person chose to hide (per stick, not in the Gist). */
    var hiddenApps: Set<String>
        get() = sp.getStringSet("hiddenApps", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("hiddenApps", v.toSet()).apply()

    /** Just the "NFL:DAL" part of each favorite team, for matching against games. */
    val myTeamKeys: Set<String>
        get() = myTeams.map { it.substringBefore('|') }.toSet()

    /** "normal", "large" or "xlarge". */
    var textSize: String
        get() = sp.getString("textSize", "normal") ?: "normal"
        set(v) = sp.edit().putString("textSize", v).apply()

    val textScale: Float
        get() = when (textSize) { "large" -> 1.2f; "xlarge" -> 1.4f; else -> 1f }

    var highContrast: Boolean
        get() = sp.getBoolean("highContrast", false)
        set(v) = sp.edit().putBoolean("highContrast", v).apply()

    /** Quiet mode: chips and sports strip dim after about 30 seconds without a key press. */
    var quietMode: Boolean
        get() = sp.getBoolean("quietMode", true)
        set(v) = sp.edit().putBoolean("quietMode", v).apply()

    /** Night dimming start hour (18 to 23), or -1 for off. Ends at 6 AM. */
    var nightStart: Int
        get() = sp.getInt("nightStart", 22)   // v0.14: on by itself from 10 PM (Galaxy Media's screen only)
        set(v) = sp.edit().putInt("nightStart", v).apply()

    /** Starfield motion: "off" (still), "reduced" (slow, subtle twinkle) or "normal". */
    /** TEMPORARY Season test: until this time the home screen cycles the holiday scenes every 5 seconds. */
    /** Year the New Year launch clip last played (it plays once, at midnight or the first time Home shows on Jan 1). */
    var launchYear: Int
        get() = sp.getInt("launchYear", 0)
        set(v) = sp.edit().putInt("launchYear", v).apply()

    var storyTestUntil: Long
        get() = sp.getLong("storyTestUntil", 0L)
        set(v) = sp.edit().putLong("storyTestUntil", v).apply()

    /** A season picked in Settings so it can be looked at today. It goes back to the real date after 30 minutes. */
    var previewScene: String
        get() = if (System.currentTimeMillis() > sp.getLong("previewUntil", 0L)) "" else (sp.getString("previewScene", "") ?: "")
        set(v) = sp.edit().putString("previewScene", v).putLong("previewUntil", System.currentTimeMillis() + 30L * 60_000L).apply()

    /** Shelf icons in the Galaxy style (on) or each app's own icon (off). */
    var galaxyIcons: Boolean
        get() = true   // Galaxy-style icons only (the "Original" choice was retired)
        set(v) = sp.edit().putBoolean("galaxyIcons", v).apply()

    /** Small holiday decorations on the app tiles when the Seasonal background is on. */
    var tileDeco: Boolean
        get() = sp.getBoolean("tileDeco", true)
        set(v) = sp.edit().putBoolean("tileDeco", v).apply()

    var motion: String
        get() = sp.getString("motion", "normal") ?: "normal"
        set(v) = sp.edit().putString("motion", v).apply()

    /** Idle screensaver (a slow-moving clock) after about 5 minutes with no key press. */
    var screensaver: Boolean
        get() = sp.getBoolean("screensaver", true)
        set(v) = sp.edit().putBoolean("screensaver", v).apply()

    /** Open Galaxy Media by itself when the stick finishes starting up. */
    var autoStart: Boolean
        get() = sp.getBoolean("autoStart", true)
        set(v) = sp.edit().putBoolean("autoStart", v).apply()

    /** Weather city for the greeting line. Blank = off. Lat/lon are saved as text. */
    var weatherName: String
        get() = sp.getString("weatherName", "") ?: ""
        set(v) = sp.edit().putString("weatherName", v).apply()

    var weatherLat: String
        get() = sp.getString("weatherLat", "") ?: ""
        set(v) = sp.edit().putString("weatherLat", v).apply()

    var weatherLon: String
        get() = sp.getString("weatherLon", "") ?: ""
        set(v) = sp.edit().putString("weatherLon", v).apply()

    /** Puts the look back to defaults. Keeps name, teams and settings link. */
    fun resetLook() {
        sp.edit().remove("accent").remove("wallpaper").remove("rotateMin").remove("edge").remove("beam").remove("sports")
            .remove("shelf").remove("textSize").remove("highContrast")
            .remove("quietMode").remove("nightStart").remove("motion").remove("screensaver").apply()
    }

    /** How often the "Cleanup due" chip comes back: "off", "weekly" or "monthly". */
    var cleanupEvery: String
        get() = sp.getString("cleanupEvery", "monthly") ?: "monthly"
        set(v) = sp.edit().putString("cleanupEvery", v).apply()

    /** Message board: the raw "_board" entry last fetched, which one we saw first and when, and the last note shown. */
    var boardRaw: String
        get() = sp.getString("boardRaw", "") ?: ""
        set(v) = sp.edit().putString("boardRaw", v).apply()

    var boardId: String
        get() = sp.getString("boardId", "") ?: ""
        set(v) = sp.edit().putString("boardId", v).apply()

    var boardSeenAt: Long
        get() = sp.getLong("boardSeenAt", 0L)
        set(v) = sp.edit().putLong("boardSeenAt", v).apply()

    var boardNoteDone: String
        get() = sp.getString("boardNoteDone", "") ?: ""
        set(v) = sp.edit().putString("boardNoteDone", v).apply()

    var lastCleanup: Long
        get() = sp.getLong("lastCleanup", 0L)
        set(v) = sp.edit().putLong("lastCleanup", v).apply()

    var cleanupSnoozeUntil: Long
        get() = sp.getLong("cleanupSnoozeUntil", 0L)
        set(v) = sp.edit().putLong("cleanupSnoozeUntil", v).apply()

    fun cleanupDue(now: Long = System.currentTimeMillis()): Boolean {
        val days = when (cleanupEvery) { "weekly" -> 7; "monthly" -> 30; else -> return false }
        if (now < cleanupSnoozeUntil) return false
        return lastCleanup == 0L || now - lastCleanup >= days * 86_400_000L
    }

    fun getAppVersion(pkg: String) = sp.getInt("ver_$pkg", 0)
    fun setAppVersion(pkg: String, v: Int) = sp.edit().putInt("ver_$pkg", v).apply()

    // Installs we handed to the system installer and are waiting to confirm.
    fun pendingPackages(): Set<String> = sp.getStringSet("pend_set", emptySet()) ?: emptySet()

    fun markPending(pkg: String, version: Int, startedAt: Long) {
        val set = pendingPackages().toMutableSet().apply { add(pkg) }
        sp.edit()
            .putStringSet("pend_set", set)
            .putInt("pend_ver_$pkg", version)
            .putLong("pend_ts_$pkg", startedAt)
            .apply()
    }

    fun pendingVersion(pkg: String) = sp.getInt("pend_ver_$pkg", 0)
    fun pendingStartedAt(pkg: String) = sp.getLong("pend_ts_$pkg", 0L)

    fun clearPending(pkg: String) {
        val set = pendingPackages().toMutableSet().apply { remove(pkg) }
        sp.edit().putStringSet("pend_set", set).apply()
    }
}
