package com.galaxymedia.tvsetup

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Turns a short setup code (like GAL-4821) into the settings file link.
 * The code list is a small file in the repo: setup-codes.json, {"GAL-4821": "<32-character Gist code>"}.
 * A full link or a bare 32-character Gist code is accepted too.
 */
object SetupCodes {

    private const val CODES_URL =
        "https://gist.githubusercontent.com/galaxystreamingservice-droid/4f0ff093b9423982b318fb21320b1c70/raw/setup-codes.json"

    class Result(val url: String?, val error: String?)

    fun gistUrl(code: String) =
        "https://gist.githubusercontent.com/galaxystreamingservice-droid/${code.lowercase()}/raw/device-settings.json"

    private val hex32 = Regex("^[0-9a-fA-F]{32}$")

    /** data is the "_payment" block, or null. reachable is false only when the internet itself failed. */
    class PaymentResult(val data: JSONObject?, val reachable: Boolean)

    /** The "_payment" block of the secret codes file (QR pictures and the text-me note). Blocking. */
    fun payment(): PaymentResult = try {
        val conn = (URL(CODES_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "galaxy-media")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        PaymentResult(JSONObject(body).optJSONObject("_payment"), true)
    } catch (e: java.io.FileNotFoundException) {
        PaymentResult(null, true)          // reached GitHub, but the file is not there
    } catch (e: java.io.IOException) {
        PaymentResult(null, false)         // no internet, or a timeout
    } catch (e: Exception) {
        PaymentResult(null, true)          // reached it, but could not read it
    }

    /** The "_tips" block of the codes file: {"intro": "...", "items": [{"title","note","url"}]}. Blocking. */
    fun tips(): PaymentResult = try {
        val conn = (URL(CODES_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "galaxy-media")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        PaymentResult(JSONObject(body).optJSONObject("_tips"), true)
    } catch (e: java.io.IOException) {
        PaymentResult(null, false)
    } catch (e: Exception) {
        PaymentResult(null, true)
    }

    /** Message board entry from the shared codes file: {"id","type":"outage|note","text","until":"yyyy-MM-dd"}. */
    fun board(): PaymentResult = try {
        val conn = (URL(CODES_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "galaxy-media")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val o = JSONObject(body)
        PaymentResult(o.optJSONObject("_board") ?: o.optJSONObject("board"), true)
    } catch (e: java.io.IOException) {
        PaymentResult(null, false)
    } catch (e: Exception) {
        PaymentResult(null, true)
    }

    /** Blocking. Call from a background thread. */
    fun resolve(input: String): Result {
        val raw = input.trim()
        if (raw.isEmpty()) return Result(null, "Nothing was entered.")
        if (raw.startsWith("http", ignoreCase = true)) return Result(raw, null)
        if (hex32.matches(raw)) return Result(gistUrl(raw), null)

        // "gal 4821", "GAL4821", "gal-4821" all become GAL-4821
        val clean = raw.uppercase().filter { it.isLetterOrDigit() }
        val key = if (clean.startsWith("GAL") && clean.length > 3) "GAL-" + clean.substring(3) else clean

        val body = try {
            val conn = (URL(CODES_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "galaxy-media")
            }
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            return Result(null, "Couldn't reach the internet. Check Wi-Fi and try again.")
        }

        val value = try {
            val obj = JSONObject(body)
            obj.keys().asSequence().firstOrNull { it.trim().uppercase() == key }?.let { obj.optString(it) }
        } catch (e: Exception) { null }

        if (value.isNullOrBlank()) return Result(null, "Code not found. Check it and try again.")
        val v = value.trim()
        return when {
            v.startsWith("http", ignoreCase = true) -> Result(v, null)
            hex32.matches(v) -> Result(gistUrl(v), null)
            else -> Result(null, "That code is set up wrong. Ask the owner.")
        }
    }
}
