plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.galaxymedia.tvsetup"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.galaxymedia.tvsetup"
        minSdk = 25 // Fire OS 6+ (Fire TV Stick 4K 1st gen and newer)
        targetSdk = 34
        versionCode = 83
        versionName = "0.14.3"
    }

    // One fixed signing key, so every build installs over the last one without an uninstall.
    signingConfigs {
        getByName("debug") {
            storeFile = file("galaxy-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        // HOME TEST build: installs next to the normal app (own app id, own settings) and also
        // answers the Home button. Built only by the manual "Build HOME test APK" workflow.
        create("hometest") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".hometest"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // Holiday clips are read straight from the APK (openFd), so keep them uncompressed.
    androidResources { noCompress += listOf("mp4") }
    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*",
            "META-INF/versions/**", "META-INF/*.kotlin_module"
        )
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.zxing:core:3.5.3")
}
